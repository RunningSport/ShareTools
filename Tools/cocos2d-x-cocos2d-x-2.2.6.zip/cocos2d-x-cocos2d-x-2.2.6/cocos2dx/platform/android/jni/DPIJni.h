#ifndef __DPIJNI_H__
#define __DPIJNI_H__

extern "C" {

int getDPIJNI();

} // extern "C"

#endif /* __DPIJNI_H__ */
