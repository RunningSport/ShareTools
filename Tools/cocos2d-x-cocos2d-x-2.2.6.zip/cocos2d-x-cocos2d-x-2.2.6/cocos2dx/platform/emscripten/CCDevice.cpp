#include "platform/CCDevice.h"

NS_CC_BEGIN

int CCDevice::getDPI()
{
    return 160;
}

NS_CC_END
