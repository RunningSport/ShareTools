﻿#pragma once

#include "cocos2d.h"
